(function ()
{
  const scriptSrc = document.currentScript.src;
  const re = /([a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12})/i;
  const packageId = re.exec(scriptSrc.toLowerCase())[1];
  const packagePath = scriptSrc.replace('/scripts/scripts.js', '').trim();
  const pathname = (window.location.pathname + window.location.search).toLowerCase();
  let inputType;
  let customfields;

  $(document).ready(function ()
  {
    if (pathname.indexOf('/user/marketplace/user-settings') > -1 || pathname.indexOf('/user/marketplace/seller-settings') > -1) {
      loadCustomFields();

      $('body').on('click', '#next-tab', function ()
      {

        getCustomFieldValues();

      });
    }
  });

  function loadCustomFields()
  {
    var apiUrl = packagePath + '/get_customfields.php';
    $.ajax({
      url: apiUrl,
      method: 'POST',
      contentType: 'application/json',
      data: JSON.stringify(),
      success: function (result)
      {
        var response = $.parseJSON(result);
        console.log(response);
        if (response.result !== null) {
          $('.seller-common-box').addClass('clearfix');
          //append a parent div on 'eller-common-box'
          const customParentDiv = '<div id ="customfields"> </div>';
          $('.seller-common-box').append(customParentDiv);
          let count = 1;
          $.each(response.result, function (index, cf)
          {
            //dropdown
            if (cf.Type == 'dropdown') {
              let options;
              $.each(cf.Options, function (index, option)
              {
                options += `<option name='${option.Name}' value="${option.Name}">${option.Name}</option>`
              });
              inputType = `<select id="${cf.Code}" class=''>
              ${options}
                </select>`;
            };
            //text field
            if (cf.Type == 'textfield') {
              inputType = `<input type="text" name="${cf.Name}" id="${cf.Code}" class="required" value="" >`;
            }
            //check box
            if (cf.Type == 'checkbox') {
              let chkoptions = '';
              $.each(cf.Options, function (index, option)
              {
                chkoptions += `<div class="fancy-checkbox checkbox-sm"><input data-name="${option.Name}" dir="${cf.Code}" id="${option.Name}" type= ${cf.Type} >
                <label for="${option.Name}"><span>${option.Name}</span>
                </label>  </div>`
              });
              inputType = `<div class="customcheckbox" id="${cf.Code}" > 
               ${chkoptions}
              </div>`;
            }
            //number
            if (cf.Type == 'number') {
              inputType = `<input type="number" name="${cf.Name}" id="${cf.Code}" class="required" value="" >`;
            }
            //appending on the 'seller-box'
            if (count % 2 != 0) {
              customfields = `<div class="item-form-group"><div class="col-md-6" > <label>${cf.Name.toUpperCase()}</label>
              ${inputType} </div></div>`;
              $('#customfields').append(customfields);
            } else {
              customfields = `<div class="col-md-6"> <label>${cf.Name.toUpperCase()}</label>
              ${inputType} </div>`;
              $('#customfields .item-form-group:last').append(customfields);
            }
            count++;

            loadCustomFieldValues(cf.Code, cf.Type);
          });

        }
      },
      error: function (jqXHR, status, err)
      {
        console.log(err);
      }
    });
  }
  function getCustomFieldValues()
  {
    //get all the textfields and dropdowns
    customfield_data = [];
    checkbox_data = [];

    $('#customfields').find(':input').each(function ()
    {
      textfield_data = [];
      if ($(this).attr('type') != 'checkbox') {
        let custom_code = $(this).attr('id');
        let custom_value = $(this).val();
        textfield_data.push(custom_value);

        customfield_data.push({ 'code': custom_code, 'Values': textfield_data })
      }
    });
    //for checkboxes
    $('.customcheckbox').each(function ()
    {
      let chkoptions = [];
      $(this).find(':checkbox:checked').each(function ()
      {
        console.log($(this).attr('data-name'));
        chkoptions.push($(this).attr('data-name'));
      });
      customfield_data.push({ 'code': $(this).attr('id'), 'Values': chkoptions });
    });
    console.log(customfield_data);
    saveCustomFiedldValues(customfield_data);
  }
  function saveCustomFiedldValues(data)
  {
    var data = { 'customfield_data': data };
    console.log(data);
    const apiUrl = packagePath + '/save_customfields.php';
    $.ajax({
      url: apiUrl,
      method: 'POST',
      contentType: 'application/json',
      data: JSON.stringify(data),
      success: function (response)
      {
        console.log(JSON.stringify(response));
      },
      error: function (jqXHR, status, err)
      {

      }
    });
  }
  function loadCustomFieldValues(customFieldCode, type)
  {
    const apiUrl = packagePath + '/get_customfield_values.php';
    let data = { 'code': customFieldCode };
    $.ajax({
      url: apiUrl,
      method: 'POST',
      contentType: 'application/json',
      data: JSON.stringify(data),
      success: function (result)
      {
        var response = $.parseJSON(result);
        if (response != null || response.length != 0) {
          if (type == 'textfield' || type == 'dropdown') {
            $('#' + customFieldCode + '').val(response.result[0].Values[0]);
          }
          if (type == 'number') {
            $('#' + customFieldCode + '').val(parseInt(response.result[0].Values[0]));
          }
          if (type == 'checkbox') {
            $.each(response.result[0].Values, function (index, option)
            {
              $('#' + option + '').prop("checked", true);
            });
          }
        }
      },
      error: function (jqXHR, status, err)
      {
        console.log(err);
      }
    });
  }

})();
