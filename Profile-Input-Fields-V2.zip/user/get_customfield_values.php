<?php
include 'callAPI.php';
include 'admin_token.php';
$contentBodyJson = file_get_contents('php://input');
$content = json_decode($contentBodyJson, true);
$custom_code = $content['code'];
$baseUrl = getMarketplaceBaseUrl();
$admin_token = getAdminToken();

$url = $baseUrl . '/api/v2/users/';
$result = callAPI("GET", $admin_token['access_token'], $url, false);
$adminId = $result['ID'];

$userToken = $_COOKIE["webapitoken"];
$url = $baseUrl . '/api/v2/users/';
$result = callAPI("GET", $userToken, $url, false);
$userId = $result['ID'];

// $url = $baseUrl . '/api/v2/users/' . $userId;
// $result = callAPI("GET", null, $url, false);

//$url = $baseUrl . '/api/v2/admins/' . $adminId . '/users?pageSize=1000';
$url = $baseUrl . '/api/v2/users/' . $userId;
$result = callAPI("GET", $admin_token['access_token'], $url, false);

$customfield_data = [];

foreach ($result['CustomFields'] as $customfield) {
    if ($customfield['Code'] == $custom_code) {
        $customfield_data[] = array('Code' => $customfield['Code'], 'Name' => $customfield['Name'], 'Values' => $customfield['Values'], 'Type' => $customfield['DataFieldType']);
    }
}


echo json_encode(['result' => $customfield_data]);
