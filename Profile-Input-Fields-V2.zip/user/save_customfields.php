<?php
include 'callAPI.php';
include 'admin_token.php';
$contentBodyJson = file_get_contents('php://input');
$content = json_decode($contentBodyJson, true);
$custom_data = $content['customfield_data'];

$baseUrl = getMarketplaceBaseUrl();
$admin_token = getAdminToken();
$customFieldPrefix = getCustomFieldPrefix();

$userToken = $_COOKIE["webapitoken"];
$url = $baseUrl . '/api/v2/users/';
$result = callAPI("GET", $userToken, $url, false);
$userId = $result['ID'];

$all_custom_fields = [];

foreach ($custom_data as $customfield) {

    $all_custom_fields[] = $customfield;
}
$data = [
    'CustomFields' => $all_custom_fields
];

echo json_encode(['data' => $data]);
$url = $baseUrl . '/api/v2/users/' . $userId;
$result = callAPI("PUT", $admin_token['access_token'], $url, $data);
echo json_encode(['result' => $result]);
